# CodeAlpha_PasswordStrengthChecker

## Password Strength Checker - Cyber Security Internship Task 4

This Python script checks the strength of a user-entered password based on commonly accepted security criteria. It provides helpful suggestions if the password is weak or moderate.

### Technologies Used
- Python 3
- re (Regular Expressions) module

### How It Works
- Takes a password as input from the user
- Checks for the following:
  - Minimum length of 8 characters
  - Presence of uppercase letters
  - Presence of lowercase letters
  - Presence of digits
  - Presence of special characters
- Based on these checks, the script categorizes the password as:
  - Weak
  - Moderate
  - Strong
- If not strong, it provides relevant suggestions

### Setup Instructions

1. No external libraries are needed (re module is built-in)

2. Run the Script:

python password_checker.py

3. Enter a password when prompted:

Enter your password: Test123!


4. Output will display the password strength and suggestions if needed.

Note: This tool is for learning and demonstration purposes. It does not store or log any passwords.

---

### Author

Kabsha Farooq  
LinkedIn: https://www.linkedin.com/in/kabsha-farooq-27218030a/

This project was completed as part of the CodeAlpha Cyber Security Internship.

