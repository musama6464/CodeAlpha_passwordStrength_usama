import re

def check_strength(password):
    strength = 0
    remarks = []

    if len(password) >= 8:
        strength += 1
    else:
        remarks.append("Password should be at least 8 characters.")

    if re.search(r"[A-Z]", password):
        strength += 1
    else:
        remarks.append("Add at least one uppercase letter.")

    if re.search(r"[a-z]", password):
        strength += 1
    else:
        remarks.append("Add at least one lowercase letter.")

    if re.search(r"[0-9]", password):
        strength += 1
    else:
        remarks.append("Add at least one digit.")

    if re.search(r"[!@#$%^&*()_+=\-{}\[\]:;\"'<>,.?/]", password):
        strength += 1
    else:
        remarks.append("Add at least one special character.")

    if strength == 5:
        return "Strong", []
    elif 3 <= strength < 5:
        return "Moderate", remarks
    else:
        return "Weak", remarks

# Take input from user
password = input("Enter your password: ")
level, feedback = check_strength(password)

print(f"\nPassword Strength: {level}")
if feedback:
    print("Suggestions:")
    for remark in feedback:
        print(f"- {remark}")
